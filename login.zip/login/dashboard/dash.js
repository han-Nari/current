let activePage = window.location.pathname;
let navLinks = document.querySelectorAll('a');

navLinks.forEach(item => {
    if(item.href.includes(`${activePage}`)) {
        item.classList.add('active');
    }
});

let navBtn = document.querySelector('.bar');
let sideBar = document.querySelector('nav');
let ul = document.querySelector('ul');
let changeIcon = document.querySelector('.fa-bars');
let main = document.querySelector('main');

navBtn.addEventListener('click', () => {
    main.classList.toggle('slide');
});

let closed = document.querySelector('.closed');
    closed.addEventListener('click', ()=> {
    main.classList.remove('slide');
});

let x = document.querySelector('.remove');
    x.addEventListener('click', ()=> {
    document.querySelector('.update, .data, .sub').remove("closed");
});

let modi = document.querySelector('.edit');
let mark = document.querySelector(".cls");
let edit = document.querySelector('.edits');

    mark.addEventListener("click", () => {
        edit.style.display = "block";
    });

    modi.addEventListener('click', () => {
        edit.style.display = "block";
    });
