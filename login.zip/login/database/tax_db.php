<?php 
	require_once "../includes/session.php";
	require_once "../includes/finance_db_connect.php";
	require_once "tax_db_fetch.php";
	require_once "delete.php";

	$admin_id = $_SESSION['email'];

	if (!isset($admin_id)) {
	    header('location:../login.php');
	}
	
	if (!isset($_SESSION["passCode"])) {
	    header('location: database.php');
	    exit;
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<script type="text/javascript">
		window.history.forward();
	</script>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin</title>

	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="../img/logo.png">

	<!-- Jquery -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
	
	<!-- ==== Icon ==== -->
	<script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

	<!-- ==== Css Link ==== -->
	<style>
		<?php include "../dashboard/dash.css"; ?>
		<?php include "../table/table.css"; ?>
	</style>
</head>
<body>
	<main>
	<!-- Sidebar -->
	<?php include "../dashboard/side.php";?>

	<!-- Header -->
	<?php include "../dashboard/header.php";?>

	<!-- Main content -->
		<section>
			<?php if(isset($_SESSION["success"])) : ?>
					<div class="update">
						<strong><?php echo $_SESSION["success"];?></strong>
						<i class="fa-solid fa-xmark remove"></i>
					</div>
					<?php unset($_SESSION["success"]); ?>
			<?php endif; ?>

			<?php if(isset($_SESSION["delete"])) : ?>
					<div class="update deleted">
						<strong><?php echo $_SESSION["delete"];?></strong>
						<i class="fa-solid fa-xmark remove"></i>
					</div>
					<?php unset($_SESSION["delete"]); ?>
			<?php endif; ?>
			<div class="back">
				<a href="rpt_db.php"><i class="fa-solid fa-arrow-right-arrow-left"></i></a>
			</div>
			<div class="container">
				<div class="auto">
					<table>
						<caption>
							Tax Database
						</caption>
						<thead>
							<tr>
								<th>No</th>
								<th>Assesses Value</th>
								<th>Basic Tax</th>
								<th>Sef</th>
								<th>Total Tax</th>
								<th>Date</th>
								<th>Update</th>
								<th>Delete</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($results as $result) : ?>
								<tr>
									<td data-cell="No"><?php echo $result["id"]; ?></td>
									<td data-cell="Assesses Value"><?php echo $result["assessed_value"]; ?></td>
									<td data-cell="Basic Tax"><?php echo $result["basic_tax"]; ?></td>
									<td data-cell="Sef"><?php echo $result["sef"]; ?></td>
									<td data-cell="Total Tax"><?php echo $result["total_tax"]; ?></td>
									<td data-cell="Date"><?php echo $result["created_at"]; ?></td>
									<td data-cell="Update"><a class="edit" href="update.php?id=<?php echo htmlspecialchars($result["id"]); ?>">Update</a></td>
									<td data-cell="Delete">
										<form action="<?php htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">	
											<button onclick="return confirm('Do you want to delete <?php echo $result["id"]; ?>')" id="delete_button" type="submit" name="delete" class="delete" value="<?php echo htmlspecialchars($result["id"]); ?>">Delete</button>
											<a href="javascript:void"></a>
										</form>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>	
		</section>
	</main>
	<script>
		<?php include "../dashboard/dash.js"; ?>
	</script>
</body>
</html>



	