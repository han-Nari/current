<?php 
$errors = array("expenses" => "", "amount" => "", "desc" => "");
if($_SERVER["REQUEST_METHOD"] === "POST") {
	$expenseType = $_POST['newExpense'];
	$amount = $_POST['amount'];
	$description = $_POST['description'];

	// Errors handlers
	if(empty($expenseType)) {
		$errors["expenses"] = "Fill up the form!";
	} elseif(!preg_match('/^[a-zA-Z]+$/', $expenseType)) {
		$errors["expenses"] = "Only letter is allowed!";
	}

	if(empty($amount)) {
		$errors["amount"] = "Fill up the form!";
	}

	if(empty($description)) {
		$errors["desc"] = "Fill up the form!";
	} elseif(!preg_match('/^[a-zA-Z]+$/', $expenseType)) {
		$errors["desc"] = "Only letter is allowed!";
	}


	if(array_filter($errors)) {
		// Error
	} else {
		// Save to database
		$query = "INSERT INTO expenses (type, amount, particulars) VALUES(:type, :amount, :particulars)";
		$stmt = $pdo->prepare($query);
		$stmt->bindParam(":type", $expenseType);
		$stmt->bindParam(":amount", $amount);
		$stmt->bindParam(":particulars", $description);
		$stmt->execute();

		if($stmt) {
			$_SESSION['message'] = "Record created successfully";
			header("location: expense.php");
			exit();
		}
	}

}