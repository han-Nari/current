<?php 

ini_set('session.use_only_cookie', 1);
ini_set('session.use_strict_mode', 1);

session_set_cookie_params([
    'lifetime' => 1800, // 30mins
    'path' => '/',
    'secure' => true,
    'httponly' => true
]);

session_start();

// Check if the session has expired
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 1800)) {
    // Session has expired, destroy it
    session_unset();
    session_destroy();
} else {
    // Update last activity time
    $_SESSION['last_activity'] = time();
}

// Regenerate session ID if necessary
if (!isset($_SESSION["last_generation"]) || time() - $_SESSION["last_generation"] > 1800) {
    regeneration_session_id();
} else {
    // Update last generation time
    $_SESSION["last_generation"] = time();
}

function regeneration_session_id() {
    session_regenerate_id(true);
    $_SESSION["last_generation"] = time();
}
